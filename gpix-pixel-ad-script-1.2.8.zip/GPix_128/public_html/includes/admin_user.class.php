<?php

// admin_user.class.php
// ORM model for admin_users table

require_once('model.class.php');

class Admin_User extends Model
{

}

?>
