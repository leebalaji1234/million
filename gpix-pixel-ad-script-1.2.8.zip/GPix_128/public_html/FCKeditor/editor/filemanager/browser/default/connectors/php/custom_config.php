<?php 
// customizations added for GPix
require_once('../../../../../../../config.php');
$Config['Enabled'] = true ;
$Config['UserFilesPath'] = DOC_ROOT . 'UserFiles/' ;
$Config['UserFilesAbsolutePath'] = PACKAGE_ROOT . 'UserFiles/' ;
?>
