<?php

// smarty plugin: {end_form}
// returns a form end tag, along with some optional javascript to

function smarty_function_end_form($params, &$smarty)
{
  return '</form>';
}

?>
