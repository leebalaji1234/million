<?php

// user.class.php
// ORM model for users table

require_once('model.class.php');

class User extends Model
{

}

?>
