<?php

// lang.inc.php
// create global $lang object

require_once('lang.class.php');


$lang = new Lang;
?>
