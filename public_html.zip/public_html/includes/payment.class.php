<?php

// payment.class.php
// ORM model for payments table

require_once('model.class.php');

class Payment extends Model
{

}

?>
