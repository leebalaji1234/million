<?php

// app.inc.php
// create global $app object

require_once('app.class.php');

$app = new App;

?>
