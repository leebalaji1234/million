<?php

// language_text.class.php
// ORM model for language_texts table

require_once('model.class.php');

class Language_Text extends Model
{

}

?>
