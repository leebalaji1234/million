<?php

 
require_once('model.class.php');

class Drawing_report extends Model
{

}

?>
