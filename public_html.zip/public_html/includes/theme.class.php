<?php

// theme.class.php
// ORM model for regions table

require_once('model.class.php');

class Theme extends Model {

   
}

?>