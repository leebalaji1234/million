<?php

// parent_detail.class.php
// ORM model for admin_users table

require_once('model.class.php');

class Parent_Detail extends Model
{

}

?>
