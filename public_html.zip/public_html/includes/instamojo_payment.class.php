<?php 
require_once('model.class.php');

class Instamojo_payment extends Model
{

  

}

?>
