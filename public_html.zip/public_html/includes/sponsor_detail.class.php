<?php
 
require_once('model.class.php');

class Sponsor_detail extends Model {
  
}

?>