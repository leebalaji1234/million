<?php

// volunteer.class.php
// ORM model for volunteer table

require_once('model.class.php');

class State extends Model
{
	

}

?>
