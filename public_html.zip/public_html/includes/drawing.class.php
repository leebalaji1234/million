<?php

// drawing.class.php
// ORM model for drawing table

require_once('model.class.php');

class Drawing extends Model
{

}

?>
