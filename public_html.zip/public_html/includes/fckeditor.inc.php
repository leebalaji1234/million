<?php

// fckeditor.php
// load FCKeditor interface

require_once(PACKAGE_ROOT . 'FCKeditor/fckeditor.php');

?>
