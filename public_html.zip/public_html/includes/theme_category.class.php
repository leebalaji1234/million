<?php

// drawing_like.class.php
// ORM model for payments table

require_once('model.class.php');

class Theme_categorie extends Model
{

}

?>
