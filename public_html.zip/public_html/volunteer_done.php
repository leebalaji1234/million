<?php

require_once('config.php');
 

$smarty->display('volunteer_done.tpl');

?>
