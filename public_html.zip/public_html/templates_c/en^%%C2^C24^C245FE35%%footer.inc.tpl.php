<?php /* Smarty version 2.6.12, created on 2016-04-24 03:41:35
         compiled from admin/footer.inc.tpl */ ?>
    </div></td></tr></table>
  </body>
</html>