<?php /* Smarty version 2.6.12, created on 2016-04-24 03:43:50
         compiled from footer.inc.tpl */ ?>
<!-- footer -->
<div class="section">
  <div class="navbar navbar-default navbar-fixed-bottom" style="-webkit-box-shadow:inset 22px 22px 22px 22px #FC3059;
box-shadow:inset 22px 22px 22px 22px #ffffff;">
        <div class="container">
          <div class="navbar-header">
            <a class="navbar-brand"><span>Copyright@2016 milliondollardrawings.com</span></a>
          </div>
          <div class="collapse navbar-collapse" id="navbar-ex-collapse">
            <ul class="nav navbar-nav navbar-right">
              <li>
                <a href="index.php#drawings">Top Drawings</a>
              </li>
              <li>
                <a href="index.php#sponsors">Top Sponsors</a>
              </li>
              <li>
                <a href="index.php#volunteers">Top Volunteers</a>
              </li>
              <li>
                <a href="#">Press</a>
              </li>
              <li>
                <a href="#">FAQ</a>
              </li>
              <li>
                <a href="#">Press</a>
              </li>
              <li>
                <a href="#">Testimonials</a>
              </li>
              <li>
                <a href="#">Contact</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      </div>
    </div>
  </body>
</html>